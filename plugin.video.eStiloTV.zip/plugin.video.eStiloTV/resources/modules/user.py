import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmVTdGlsb1RW')

name = b.b64decode('ZVN0aWxvVFY=')

host = b.b64decode('aHR0cDovL2xvZ2ludG8udHY=')

port = b.b64decode('ODM=')